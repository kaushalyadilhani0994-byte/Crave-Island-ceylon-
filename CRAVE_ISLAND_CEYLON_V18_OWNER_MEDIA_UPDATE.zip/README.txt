CRAVE ISLAND CEYLON — V18 OWNER MEDIA REFINEMENT

Main file: index.html
Artwork: original-opening-artwork.jpg

Updates in this build:
- Photo-led Media Lounge, Star Points/Loyalty and Scratch Rewards cards.
- Owner image studio for selecting and previewing a category/feature image. Browser demo saves locally on this device only.
- Clearer team invitation form with name, work email, requested role and draft status. It does not send email or grant access.
- Luxury cocoa/gold styling preserved.

Important production work still required:
- Supabase Auth email OTP, owner approval, roles and server-side authorization/RLS.
- Protected image uploads to Supabase Storage and database-managed category image URLs.
- Server-side audit logs and real team invitation delivery.
- Real social publishing integrations and permission review for each platform.
- Replace demo/stock image URLs with your original licensed brand photos.

Deploy the lowercase index.html in the existing repository root. Test in mobile browsers after deployment. Do not expose service-role keys or OAuth client secrets in this HTML.
